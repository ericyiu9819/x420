# Debian VPS 网络队列内核（VPSFQ）

这套构建包以 Debian VPS 通用低冗余内核为基线，新增独立的 `vpsfq`
队列调度器。VPSFQ 派生自 Linux 6.12.97 上游 FQ，保留逐流公平调度和
TCP pacing，只调整面向 1 核、小内存云 VPS 的默认参数。

默认内核版本：Linux 6.12.97 LTS。

## 设计边界

保留：

- KVM/VirtIO、Xen、Hyper-V、VMware；
- VirtIO、SCSI、NVMe及当前 Debian 基线中的存储支持；
- AWS ENA、Google GVE、Azure MANA及常见 SR-IOV 网卡；
- BBR + VPSFQ 默认策略，以及 CUBIC、原版 FQ、FQ-CoDel、CAKE、
  RPS/RFS/XPS；
- nftables、iptables兼容层、NAT、TUN、WireGuard；
- 容器所需的 namespace、cgroup、VETH、Bridge和OverlayFS；
- BPF/XDP运行能力。

删除：

- DRM、帧缓冲、声音、多媒体；
- Wi-Fi、蓝牙、NFC、业余无线电和物联网协议；
- PCMCIA、FireWire、Thunderbolt以及传感器类硬件；
- 冷门或集群文件系统；
- KASAN、KCSAN、UBSAN、KUnit等重型调试和测试设施。
- DWARF/BTF调试信息，以降低构建空间、包体积和编译时间。

未加载的模块主要占用磁盘，并不持续占用运行内存。因此这套配置以降低包体积、
initramfs体积和攻击面为主，不承诺单靠裁剪提升网络吞吐。

## 适用条件

- Debian amd64；
- 完整虚拟机，例如 KVM、Xen HVM、VMware或Hyper-V；
- 能访问供应商串口/VNC控制台或救援系统；
- `/boot` 中保留当前 Debian 官方内核。

不适用于 OpenVZ、LXC、Docker或其他共享宿主机内核的容器。

## 1. 安装构建依赖

```bash
sudo apt update
sudo apt install --yes \
  build-essential bc bison flex libssl-dev libelf-dev libncurses-dev \
  dwarves fakeroot rsync cpio kmod curl xz-utils zstd dpkg-dev debhelper
```

建议至少准备 15 GiB 空闲磁盘。小内存 VPS 可以增加 swap，或者在另一台
同版本 Debian amd64 机器上构建。

## 2. 构建

在本目录运行：

```bash
chmod +x scripts/build.sh scripts/verify-config.sh scripts/apply-queue-profile.sh
./scripts/build.sh
```

默认使用：

```text
/boot/config-$(uname -r)
```

作为基线。产物位于：

```text
vps-kernel-build/packages/
```

配置差异位于：

```text
vps-kernel-build/output-6.12.97/config-diff.txt
```

合并时使用“内置优先”规则：如果 Debian 基线已将根文件系统或某个启动驱动
设为内置，精简片段不会把它降级成模块。

可以调整并行数和构建目录：

```bash
JOBS=2 BUILD_ROOT=/var/tmp/vps-kernel-build ./scripts/build.sh
```

构建并存的实验修订版时，应使用不同的发布名和 Debian 包版本：

```bash
LOCAL_VERSION=-vpsfq-test \
KDEB_PKGVERSION=6.12.97-4 \
./scripts/build.sh
```

不要在不同版本源码之间复用旧的输出目录。

## 3. 安装，但先不要删除旧内核

检查生成的包：

```bash
ls -lh vps-kernel-build/packages/
```

安装内核映像和头文件：

```bash
sudo dpkg -i \
  vps-kernel-build/packages/linux-image-*.deb \
  vps-kernel-build/packages/linux-headers-*.deb
```

确认 initramfs 和 GRUB 项目已经生成：

```bash
ls -lh /boot/initrd.img-*vpsfq*
grep -R "vpsfq" /boot/grub/grub.cfg
```

如果系统没有 `/boot/grub/grub.cfg`，需要先确认供应商采用的引导方式。
不要在不清楚引导方式时重启。

## 4. 首次重启和回滚

首次启动前确保供应商控制台和救援模式可用。保留原 Debian 内核，不要把
自定义内核设置为唯一启动项。

重启后验证：

```bash
uname -r
systemctl --failed
ip -br link
ip route
```

如果无法联网或启动，从供应商控制台的 GRUB “Advanced options” 中选择旧的
Debian 内核。无法进入 GRUB 时使用供应商救援系统挂载磁盘并恢复默认启动项。

## 5. 队列策略

内核的编译默认值是 BBR + VPSFQ。VPSFQ 提供逐流公平排队和 pacing，
并采用以下保守参数：

- 总队列上限：4096 个包（上游 FQ 默认 10000）；
- 单流上限：64 个包（上游默认 100）；
- 流表桶数：512（上游默认 1024）；
- 调度 quantum：4 × MTU（上游默认 2 × MTU）；
- 初始 quantum：8 × MTU（上游默认 10 × MTU）；
- 定时器 slack：20 微秒（上游默认 10 微秒）；
- pacing horizon：2 秒（上游默认 10 秒）。

这些调整的目标是降低小内存 VPS 的排队内存和单核调度开销，同时限制单流
突发。它们不是“增加物理带宽”的补丁，必须通过 A/B 测试与原版 FQ 比较。
原版 FQ、FQ-CoDel 和 CAKE 继续保留：

- `throughput`：BBR + VPSFQ，适合日常上网、视频和大流量 TCP；
- `balanced`：BBR + FQ-CoDel，适合更重视混合交互流量延迟的场景；
- `shaped RATE`：BBR + CAKE，仅在已知出口瓶颈速率并主动整形时使用。

确认新内核运行正常后：

```bash
sudo install -m 0644 \
  sysctl/90-network-throughput.conf \
  /etc/sysctl.d/90-network-throughput.conf
sudo sysctl --system
```

要让策略立即作用于当前默认路由网卡，而不等待接口重新创建：

```bash
sudo ./scripts/apply-queue-profile.sh throughput
```

切换低延迟档：

```bash
sudo ./scripts/apply-queue-profile.sh balanced
```

仅在实测出口上限明确时使用 CAKE，并将速率设置为真实瓶颈的约 90%–95%：

```bash
sudo ./scripts/apply-queue-profile.sh shaped 500mbit
```

该工具只修改默认路由网卡的出口队列，不配置入口整形，也不会突破 VPS
供应商限速。远程执行 `tc qdisc replace` 前应保留第二个 SSH 会话或供应商控制台。

验证：

```bash
sysctl net.core.default_qdisc
sysctl net.ipv4.tcp_congestion_control
sysctl net.ipv4.tcp_available_congestion_control
tc qdisc show
```

预期默认队列规则为 `vpsfq`，拥塞控制为 `bbr`。BBR 已直接编入内核，因此
`lsmod` 没有 `tcp_bbr` 输出是正常现象。

## 6. 升级维护

固定版本便于复现，但需要主动跟踪 6.12 LTS 安全更新。升级时：

1. 修改 `scripts/build.sh` 中默认版本和 SHA-256；
2. 使用 Kernel.org 对应版本的校验值；
3. 使用全新的构建目录；
4. 重新运行配置验证；
5. 安装新包并继续保留至少一个已验证可启动的官方内核。

## 安全说明

配置片段清除了 Debian 私有源码树中的证书文件引用，使上游源码可以完成构建。
生成的自定义内核不会自动获得 Secure Boot 信任。启用了 Secure Boot 的 VPS
必须自行签名并注册密钥，否则不能启动。

这套构建使用 HTTPS 下载并核对固定 SHA-256，但没有替代 Kernel.org 的 PGP
发布签名验证流程。对供应链要求较高时，应在构建前额外验证官方签名。
