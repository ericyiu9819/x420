#!/usr/bin/env bash
set -Eeuo pipefail

profile=${1:-}
rate=${2:-}

usage() {
    cat >&2 <<'EOF'
Usage:
  sudo ./scripts/apply-queue-profile.sh throughput
  sudo ./scripts/apply-queue-profile.sh balanced
  sudo ./scripts/apply-queue-profile.sh shaped 500mbit

Profiles affect egress queues on interfaces carrying a default route.
They do not configure ingress shaping.
EOF
    exit 2
}

[[ $EUID -eq 0 ]] || {
    echo "ERROR: run as root." >&2
    exit 1
}

case "$profile" in
    throughput|balanced) ;;
    shaped)
        [[ "$rate" =~ ^[1-9][0-9]*(kbit|mbit|gbit)$ ]] || usage
        ;;
    *) usage ;;
esac

for tool in ip tc sysctl; do
    command -v "$tool" >/dev/null || {
        echo "ERROR: missing command: $tool" >&2
        exit 1
    }
done

mapfile -t interfaces < <(
    {
        ip -o route show default 2>/dev/null
        ip -o -6 route show default 2>/dev/null
    } | awk '
        {
            for (i = 1; i <= NF; i++) {
                if ($i == "dev" && (i + 1) <= NF) {
                    print $(i + 1)
                }
            }
        }
    ' | sort -u
)

(( ${#interfaces[@]} > 0 )) || {
    echo "ERROR: no default-route interface found." >&2
    exit 1
}

sysctl -q -w net.ipv4.tcp_congestion_control=bbr

case "$profile" in
    throughput)
        for interface in "${interfaces[@]}"; do
            tc qdisc replace dev "$interface" root vpsfq
        done
        sysctl -q -w net.core.default_qdisc=vpsfq
        ;;
    balanced)
        for interface in "${interfaces[@]}"; do
            tc qdisc replace dev "$interface" root fq_codel
        done
        sysctl -q -w net.core.default_qdisc=fq_codel
        ;;
    shaped)
        for interface in "${interfaces[@]}"; do
            tc qdisc replace dev "$interface" root cake bandwidth "$rate" besteffort
        done
        sysctl -q -w net.core.default_qdisc=cake
        ;;
esac

echo "Applied profile: $profile"
for interface in "${interfaces[@]}"; do
    tc -s qdisc show dev "$interface"
done
