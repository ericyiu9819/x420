#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
PROJECT_DIR=$(cd -- "${SCRIPT_DIR}/.." && pwd)

KERNEL_VERSION=${KERNEL_VERSION:-6.12.97}
KERNEL_SHA256=${KERNEL_SHA256:-6cbddfa3bbd2229026f7cc5e48f6b7d6b46d39742de39a9257a2f490a0f45c6f}
KERNEL_URL=${KERNEL_URL:-https://cdn.kernel.org/pub/linux/kernel/v6.x/linux-${KERNEL_VERSION}.tar.xz}
BASE_CONFIG=${BASE_CONFIG:-/boot/config-$(uname -r)}
BUILD_ROOT=${BUILD_ROOT:-"$PWD/vps-kernel-build"}
LOCAL_VERSION=${LOCAL_VERSION:--vpsfq}
KDEB_PKGVERSION=${KDEB_PKGVERSION:-${KERNEL_VERSION}-3}
JOBS=${JOBS:-$(nproc)}

SOURCE_ARCHIVE="${BUILD_ROOT}/linux-${KERNEL_VERSION}.tar.xz"
SOURCE_DIR="${BUILD_ROOT}/linux-${KERNEL_VERSION}"
OUTPUT_DIR="${BUILD_ROOT}/output-${KERNEL_VERSION}"
PACKAGE_DIR="${BUILD_ROOT}/packages"
FINAL_CONFIG="${OUTPUT_DIR}/.config"

die() {
    echo "ERROR: $*" >&2
    exit 1
}

command -v dpkg >/dev/null || die "This build script must run on Debian."
[[ "$(dpkg --print-architecture)" == amd64 ]] || die "Only Debian amd64 is supported."
[[ -r "$BASE_CONFIG" ]] || die "Base config not found: ${BASE_CONFIG}"

virt=$(systemd-detect-virt 2>/dev/null || true)
case "$virt" in
    lxc|openvz|docker|podman|systemd-nspawn)
        die "The current environment (${virt}) shares its host kernel and cannot boot a custom kernel."
        ;;
esac

for tool in curl tar xz make gcc bc bison flex openssl pahole fakeroot rsync cpio dpkg-buildpackage dh perl sha256sum; do
    command -v "$tool" >/dev/null || die "Missing build tool: ${tool}. See README.md."
done

mkdir -p "$BUILD_ROOT" "$OUTPUT_DIR" "$PACKAGE_DIR"

available_kib=$(df -Pk "$BUILD_ROOT" 2>/dev/null | awk 'NR==2 {print $4}' || true)
if [[ "$available_kib" =~ ^[0-9]+$ ]] && (( available_kib < 15 * 1024 * 1024 )); then
    die "At least 15 GiB free space is required in the build location."
fi

if [[ ! -f "$SOURCE_ARCHIVE" ]]; then
    echo "Downloading Linux ${KERNEL_VERSION}..."
    curl --fail --location --proto '=https' --tlsv1.2 \
        --output "${SOURCE_ARCHIVE}.partial" "$KERNEL_URL"
    mv "${SOURCE_ARCHIVE}.partial" "$SOURCE_ARCHIVE"
fi

echo "${KERNEL_SHA256}  ${SOURCE_ARCHIVE}" | sha256sum --check -

if [[ ! -d "$SOURCE_DIR" ]]; then
    tar -xJf "$SOURCE_ARCHIVE" -C "$BUILD_ROOT"
fi

"$PROJECT_DIR/scripts/apply-vpsfq-source.sh" "$SOURCE_DIR"

cp "$BASE_CONFIG" "${OUTPUT_DIR}/base.config"
cp "$BASE_CONFIG" "$FINAL_CONFIG"

echo "Merging the VPS lean profile into the Debian base config..."
KCONFIG_CONFIG="$FINAL_CONFIG" \
    "$SOURCE_DIR/scripts/kconfig/merge_config.sh" \
    -m -y -O "$OUTPUT_DIR" "$FINAL_CONFIG" "$PROJECT_DIR/config/vps-lean.config"

make -C "$SOURCE_DIR" O="$OUTPUT_DIR" olddefconfig
"$PROJECT_DIR/scripts/verify-config.sh" "$FINAL_CONFIG"

"$SOURCE_DIR/scripts/diffconfig" \
    "${OUTPUT_DIR}/base.config" "$FINAL_CONFIG" \
    > "${OUTPUT_DIR}/config-diff.txt"

echo "Building Debian packages with ${JOBS} job(s)..."
make -C "$SOURCE_DIR" O="$OUTPUT_DIR" -j "$JOBS" \
    bindeb-pkg \
    LOCALVERSION="$LOCAL_VERSION" \
    KDEB_PKGVERSION="$KDEB_PKGVERSION"

find "$BUILD_ROOT" -maxdepth 1 -type f -name '*.deb' -exec cp -f {} "$PACKAGE_DIR/" \;

echo
echo "Build complete."
echo "Packages: ${PACKAGE_DIR}"
echo "Final config: ${FINAL_CONFIG}"
echo "Config changes: ${OUTPUT_DIR}/config-diff.txt"
