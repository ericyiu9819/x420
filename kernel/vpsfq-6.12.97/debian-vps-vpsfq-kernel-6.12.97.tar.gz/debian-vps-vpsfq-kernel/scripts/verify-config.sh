#!/usr/bin/env bash
set -Eeuo pipefail

CONFIG_FILE=${1:-}

if [[ -z "$CONFIG_FILE" || ! -f "$CONFIG_FILE" ]]; then
    echo "Usage: $0 /path/to/.config" >&2
    exit 2
fi

failures=0

state_of() {
    local symbol=$1
    local line
    line=$(grep -E "^(CONFIG_${symbol}=|# CONFIG_${symbol} is not set$)" "$CONFIG_FILE" | tail -n 1 || true)
    case "$line" in
        "CONFIG_${symbol}=y") echo y ;;
        "CONFIG_${symbol}=m") echo m ;;
        "# CONFIG_${symbol} is not set") echo n ;;
        *) echo missing ;;
    esac
}

require_y() {
    local symbol=$1
    local state
    state=$(state_of "$symbol")
    if [[ "$state" != y ]]; then
        echo "FAIL: CONFIG_${symbol} must be y; found ${state}" >&2
        failures=$((failures + 1))
    fi
}

require_available() {
    local symbol=$1
    local state
    state=$(state_of "$symbol")
    if [[ "$state" != y && "$state" != m ]]; then
        echo "FAIL: CONFIG_${symbol} must be y or m; found ${state}" >&2
        failures=$((failures + 1))
    fi
}

require_n() {
    local symbol=$1
    local state
    state=$(state_of "$symbol")
    if [[ "$state" != n && "$state" != missing ]]; then
        echo "FAIL: CONFIG_${symbol} must be disabled; found ${state}" >&2
        failures=$((failures + 1))
    fi
}

for symbol in \
    GENERIC_CPU MODULES HYPERVISOR_GUEST PARAVIRT KVM_GUEST \
    VIRTIO VIRTIO_PCI VIRTIO_NET VIRTIO_BLK VIRTIO_CONSOLE SCSI SCSI_VIRTIO \
    XEN XEN_PV XEN_PVH XEN_NETDEV_FRONTEND XEN_BLKDEV_FRONTEND \
    HYPERV PCI_HYPERV HYPERV_NET HYPERV_STORAGE VMXNET3 VMWARE_PVSCSI \
    TCP_CONG_ADVANCED TCP_CONG_CUBIC TCP_CONG_BBR DEFAULT_BBR \
    NET_SCHED NET_SCH_FQ NET_SCH_VPSFQ NET_SCH_DEFAULT DEFAULT_VPSFQ \
    RPS XPS NET_RX_BUSY_POLL \
    BPF BPF_SYSCALL NETFILTER TUN IPV6 CGROUPS NAMESPACES SECCOMP \
    DEBUG_INFO_NONE
do
    require_y "$symbol"
done

for symbol in \
    ENA_ETHERNET GVE \
    MICROSOFT_MANA MLX5_CORE I40EVF IAVF IXGBEVF BNXT \
    NET_SCH_FQ_CODEL WIREGUARD NF_TABLES NF_CONNTRACK VETH BRIDGE \
    EXT4_FS XFS_FS BTRFS_FS VFAT_FS ISO9660_FS SQUASHFS OVERLAY_FS
do
    require_available "$symbol"
done

for symbol in \
    MCORE2 MATOM HZ_100 HZ_1000 DEFAULT_CUBIC DEFAULT_FQ DEFAULT_FQ_CODEL \
    DRM FB SOUND MEDIA_SUPPORT \
    WIRELESS WLAN BT NFC HAMRADIO CAN ATM FIREWIRE USB4 \
    SCSI_FC_ATTRS DEBUG_INFO DEBUG_INFO_BTF DEBUG_INFO_BTF_MODULES \
    KASAN KCSAN UBSAN DEBUG_KMEMLEAK PROVE_LOCKING FAULT_INJECTION KUNIT
do
    require_n "$symbol"
done

if [[ "$(state_of HZ_250)" != y ]]; then
    echo "FAIL: CONFIG_HZ_250 must be y" >&2
    failures=$((failures + 1))
fi

if ! grep -qx 'CONFIG_DEFAULT_TCP_CONG="bbr"' "$CONFIG_FILE"; then
    echo 'FAIL: CONFIG_DEFAULT_TCP_CONG must be "bbr"' >&2
    failures=$((failures + 1))
fi

if ! grep -qx 'CONFIG_DEFAULT_NET_SCH="vpsfq"' "$CONFIG_FILE"; then
    echo 'FAIL: CONFIG_DEFAULT_NET_SCH must be "vpsfq"' >&2
    failures=$((failures + 1))
fi

if (( failures > 0 )); then
    echo "Configuration validation failed with ${failures} issue(s)." >&2
    exit 1
fi

echo "Configuration validation passed."
