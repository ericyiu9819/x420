#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE_DIR=${1:-}
EXPECTED_FQ_SHA256=fc2d00a508842aad33cff36657ba8dd06357028f1c4403bea8a62c76ea340090

die() {
    echo "ERROR: $*" >&2
    exit 1
}

[[ -n "$SOURCE_DIR" ]] || die "Usage: $0 /path/to/linux-source"
[[ -f "$SOURCE_DIR/net/sched/sch_fq.c" ]] || die "sch_fq.c not found"

for tool in cp grep perl sha256sum; do
    command -v "$tool" >/dev/null || die "Missing tool: $tool"
done

fq_source="$SOURCE_DIR/net/sched/sch_fq.c"
vpsfq_source="$SOURCE_DIR/net/sched/sch_vpsfq.c"
kconfig="$SOURCE_DIR/net/sched/Kconfig"
makefile="$SOURCE_DIR/net/sched/Makefile"

actual_sha256=$(sha256sum "$fq_source" | awk '{print $1}')
[[ "$actual_sha256" == "$EXPECTED_FQ_SHA256" ]] ||
    die "Unexpected sch_fq.c revision: $actual_sha256"

cp -f "$fq_source" "$vpsfq_source"

perl -0pi -e '
    s{net/sched/sch_fq\.c}{net/sched/sch_vpsfq.c};
    s{(\*  Copyright \(C\) 2013-2023 Eric Dumazet <edumazet\@google\.com>\n)}
     {$1 *\n *  VPSFQ is a conservative VPS-oriented derivative. It keeps the\n *  upstream FQ pacing and fairness machinery and changes only defaults.\n};
    s{\bfq_}{vpsfq_}g;
    s{\.id\s*=\s*"fq"}{.id\t\t=\t"vpsfq"};
    s{MODULE_ALIAS_NET_SCH\("fq"\)}{MODULE_ALIAS_NET_SCH("vpsfq")};
    s{MODULE_DESCRIPTION\("Fair Queue Packet Scheduler"\)}
     {MODULE_DESCRIPTION("VPS-tuned Fair Queue Packet Scheduler")};
    s{sch->limit\s*=\s*10000;}{sch->limit\t\t= 4096;};
    s{q->flow_plimit\s*=\s*100;}{q->flow_plimit\t\t= 64;};
    s{q->quantum\s*=\s*2 \* psched_mtu\(qdisc_dev\(sch\)\);}
     {q->quantum\t\t= 4 * psched_mtu(qdisc_dev(sch));};
    s{q->initial_quantum\s*=\s*10 \* psched_mtu\(qdisc_dev\(sch\)\);}
     {q->initial_quantum\t= 8 * psched_mtu(qdisc_dev(sch));};
    s{q->vpsfq_trees_log\s*=\s*ilog2\(1024\);}
     {q->vpsfq_trees_log\t= ilog2(512);};
    s{q->orphan_mask\s*=\s*1024 - 1;}
     {q->orphan_mask\t\t= 512 - 1;};
    s{q->timer_slack = 10 \* NSEC_PER_USEC; /\* 10 usec of hrtimer slack \*/}
     {q->timer_slack = 20 * NSEC_PER_USEC; /* reduce wakeups on small VPS */};
    s{q->horizon = 10ULL \* NSEC_PER_SEC; /\* 10 seconds \*/}
     {q->horizon = 2ULL * NSEC_PER_SEC; /* bound excessive future pacing */};
' "$vpsfq_source"

if ! grep -q '^config NET_SCH_VPSFQ$' "$kconfig"; then
    perl -0pi -e '
        s{config NET_SCH_HHF}{
config NET_SCH_VPSFQ
\ttristate "VPS Fair Queue (VPSFQ)"
\thelp
\t  VPSFQ is a conservative derivative of the upstream FQ scheduler.
\t  It keeps per-flow pacing and round-robin fairness, while using
\t  memory and batching defaults intended for small cloud VPS guests.

\t  To compile this driver as a module, choose M here: the module
\t  will be called sch_vpsfq.

\t  If unsure, say N.

config NET_SCH_HHF};

        s{\tconfig DEFAULT_CODEL}{
\tconfig DEFAULT_VPSFQ
\t\tbool "VPS Fair Queue" if NET_SCH_VPSFQ

\tconfig DEFAULT_CODEL};

        s{\tdefault "fq" if DEFAULT_FQ\n}{
\tdefault "fq" if DEFAULT_FQ
\tdefault "vpsfq" if DEFAULT_VPSFQ
};
    ' "$kconfig"
fi

if ! grep -q 'CONFIG_NET_SCH_VPSFQ' "$makefile"; then
    perl -0pi -e '
        s{(obj-\$\(CONFIG_NET_SCH_FQ\)\s*\+= sch_fq\.o\n)}
         {$1obj-\$(CONFIG_NET_SCH_VPSFQ)\t+= sch_vpsfq.o\n};
    ' "$makefile"
fi

grep -q '\.id.*"vpsfq"' "$vpsfq_source" ||
    die "Failed to register vpsfq qdisc id"
grep -q 'sch->limit.*4096' "$vpsfq_source" ||
    die "Failed to apply VPSFQ queue limit"
grep -q 'vpsfq_trees_log.*ilog2(512)' "$vpsfq_source" ||
    die "Failed to apply VPSFQ flow table size"
grep -q '^config NET_SCH_VPSFQ$' "$kconfig" ||
    die "Failed to update Kconfig"
grep -q 'CONFIG_NET_SCH_VPSFQ' "$makefile" ||
    die "Failed to update scheduler Makefile"

echo "VPSFQ source integration applied."
